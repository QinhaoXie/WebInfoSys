<template>
    <v-alert type="error"
><slot></slot>
</v-alert>  
</template>